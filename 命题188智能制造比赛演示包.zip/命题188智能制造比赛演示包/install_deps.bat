@echo off
rem ============================================================
rem  One-click dependency installer for Competition 188 demo
rem  (installs flask + openpyxl via Tsinghua mirror)
rem ============================================================
chcp 65001 >nul
title Competition 188 - Install Dependencies

echo ============================================================
echo   Installing dependencies: flask, openpyxl
echo   (Using Tsinghua PyPI mirror for faster download)
echo ============================================================

where python >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python not found in PATH.
    echo   Please install Python 3.6+ from https://www.python.org/downloads/
    echo   and check "Add Python to PATH" during installation.
    pause
    exit /b 1
)

python -m pip install --upgrade pip -i https://pypi.tuna.tsinghua.edu.cn/simple

python -m pip install flask -i https://pypi.tuna.tsinghua.edu.cn/simple
if errorlevel 1 (echo [ERROR] flask install failed & pause & exit /b 1)

python -m pip install openpyxl -i https://pypi.tuna.tsinghua.edu.cn/simple
if errorlevel 1 (echo [ERROR] openpyxl install failed & pause & exit /b 1)

echo.
echo ============================================================
echo   Dependencies installed. Now run run_demo.bat
echo ============================================================
pause >nul